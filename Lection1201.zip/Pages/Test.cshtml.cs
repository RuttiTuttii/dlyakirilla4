using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Lection1202.Pages
{
    public class TestModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
